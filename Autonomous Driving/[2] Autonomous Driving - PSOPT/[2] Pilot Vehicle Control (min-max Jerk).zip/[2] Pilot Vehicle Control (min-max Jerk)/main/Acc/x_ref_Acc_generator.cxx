/*
Online supplementary materials of the paper titled 
"A Railway Accident Prevention System Using An Intelligent Pilot Vehicle"
Authored By: Shixiong Wang (1), Xinke Li (1), Zhirui Chen (1), and Yang Liu (1,2)
From (1) the Department of Industrial Systems Engineering and Management, National University of Singapore 
and  (2) the Department of Civil and Environmental Engineering, National University of Singapore

@Function: This is the first part of the codes which design the autonomous driving of the pilot vehicle.
@Author: Shixiong Wang
@Date: First Written on 4 Sep 2020, Updated on 9 Feb 2023
@Email: s.wang@u.nus.edu; wsx.gugo@gmail.com
@Site: https://github.com/Spratm-Asleaf/Pilot_Vehicle

@Externel Dependence & Acknowledgement: https://github.com/PSOPT/psopt
*/

#include "psopt.h"
#include <cmath>
#include <cstdio>

using namespace PSOPT;
using namespace std;

double m = 2e3;
double x0 = 100;
double x_max = 1500;
double vm_max = 120/3.6;
double g = 9.80665;
double epsilon = 1;
double c0 = 0.01176;
double c1 = 7.7616e-4;
double c2 = 1.6e-5;
double delta_v_max = 10;
double lambda1 = 1;
double lambda2 = 1e4;
double alpha1 = 1;
double alpha2 = 1;
double U_underline = -0.5*m;
double U_overline = 0.6*m;

double u0s = m*(c0 + c1 * vm_max + c2 * vm_max * vm_max)/epsilon;
double u0c = u0s;

/*
double get_vm(double pm)
{
   double beta = -0.008;
   return vm_max*(1-exp(beta*pm));
}
*/

//////////////////////////////////////////////////////////////////////////
///////////////////  Define the end point (Mayer) cost function //////////
//////////////////////////////////////////////////////////////////////////

adouble endpoint_cost(adouble* initial_states, adouble* final_states,
                      adouble* parameters,adouble& t0, adouble& tf,
                      adouble* xad, int iphase,Workspace* workspace)
{
   adouble gamma = parameters[0];
   return tf + lambda2 * gamma;
}

//////////////////////////////////////////////////////////////////////////
///////////////////  Define the integrand (Lagrange) cost function  //////
//////////////////////////////////////////////////////////////////////////

adouble integrand_cost(adouble* states, adouble* controls,
                       adouble* parameters, adouble& time, adouble* xad,
                       int iphase, Workspace* workspace)
{
    adouble L = lambda1 * (*controls * states[1])/vm_max;
    
    return  L;
}

//////////////////////////////////////////////////////////////////////////
///////////////////  Define the DAE's ////////////////////////////////////
//////////////////////////////////////////////////////////////////////////

void dae(adouble* derivatives, adouble* path, adouble* states,
         adouble* controls, adouble* parameters, adouble& time,
         adouble* xad, int iphase, Workspace* workspace)
{
   derivatives[0] = states[1]/vm_max - 1;
   derivatives[1] = (epsilon * (*controls)/m - c0 - c1*states[1] - c2*states[1]*states[1])/vm_max;

   path[0] = states[1] - vm_max - delta_v_max;
   path[1] = (((*controls) - u0s)*((*controls) - u0s))/(m*m) - alpha1*(states[0] - x0);
   path[2] = (((*controls) - u0c)*((*controls) - u0c))/(m*m) - alpha1*(x_max - states[0]);
   
   adouble du;		// derivative of u
   get_control_derivative(&du, 0, iphase, time, xad, workspace);		// index starting from 0, not 1
   adouble gamma = parameters[0];
   path[3] = du * du/m - gamma;
}

////////////////////////////////////////////////////////////////////////////
///////////////////  Define the events function ////////////////////////////
////////////////////////////////////////////////////////////////////////////

void events(adouble* e, adouble* initial_states, adouble* final_states,
            adouble* parameters,adouble& t0, adouble& tf, adouble* xad,
            int iphase, Workspace* workspace)

{
   e[0] = initial_states[0];
   e[1] = initial_states[1];

   e[2] = final_states[0];
   e[3] = final_states[1];
}


///////////////////////////////////////////////////////////////////////////
///////////////////  Define the phase linkages function ///////////////////
///////////////////////////////////////////////////////////////////////////

void linkages( adouble* linkages, adouble* xad, Workspace* workspace)
{
  // No linkages as this is a single phase problem
}


////////////////////////////////////////////////////////////////////////////
///////////////////  Define the main routine ///////////////////////////////
////////////////////////////////////////////////////////////////////////////

int main(void)
{

////////////////////////////////////////////////////////////////////////////
///////////////////  Declare key structures ////////////////////////////////
////////////////////////////////////////////////////////////////////////////

    Alg  algorithm;
    Sol  solution;
    Prob problem;

////////////////////////////////////////////////////////////////////////////
///////////////////  Register problem name  ////////////////////////////////
////////////////////////////////////////////////////////////////////////////

    problem.name        	        = "Pilot Vehicle Autonomous Control (min-max Jerk)";
    problem.outfilename             = "Acc (min-max Jerk).txt";

////////////////////////////////////////////////////////////////////////////
////////////  Define problem level constants & do level 1 setup ////////////
////////////////////////////////////////////////////////////////////////////

    problem.nphases   			= 1;
    problem.nlinkages           = 0;

    psopt_level1_setup(problem);

/////////////////////////////////////////////////////////////////////////////
/////////   Define phase related information & do level 2 setup  ////////////
/////////////////////////////////////////////////////////////////////////////

    problem.phases(1).nstates   	= 2;
    problem.phases(1).ncontrols 	= 1;
    problem.phases(1).nparameters 	= 1;	// gamma
    problem.phases(1).nevents     	= 4;
    problem.phases(1).npath         = 4;
    problem.phases(1).nodes         << 100;   // how many data points to output?
    									     // I tried a lot of values, I think 40 is enough here.

    psopt_level2_setup(problem, algorithm);

////////////////////////////////////////////////////////////////////////////
///////////////////  Enter problem bounds information //////////////////////
////////////////////////////////////////////////////////////////////////////


    problem.phases(1).bounds.lower.states << x0,    0;
    problem.phases(1).bounds.upper.states << x_max, vm_max + delta_v_max;

    problem.phases(1).bounds.lower.controls << U_underline;
    problem.phases(1).bounds.upper.controls << U_overline;
    
    problem.phases(1).bounds.lower.parameters(0) = 0.0;
	problem.phases(1).bounds.upper.parameters(0) = 100;

    problem.phases(1).bounds.lower.events << x0, vm_max, x_max, vm_max;
    problem.phases(1).bounds.upper.events << x0, vm_max, x_max, vm_max;

    problem.phases(1).bounds.lower.path << -1e12, -1e12, -1e12, -1e12;		// there is no lower bounds and therefore set to "-inf"
    problem.phases(1).bounds.upper.path << 0.0, 0.0, 0.0, 0.0;

    problem.phases(1).bounds.lower.StartTime    = 0;
    problem.phases(1).bounds.upper.StartTime    = 0;

    problem.phases(1).bounds.lower.EndTime      = 1e3;
    problem.phases(1).bounds.upper.EndTime      = 6e3;


////////////////////////////////////////////////////////////////////////////
///////////////////  Register problem functions  ///////////////////////////
////////////////////////////////////////////////////////////////////////////


    problem.integrand_cost 	= &integrand_cost;
    problem.endpoint_cost 	= &endpoint_cost;
    problem.dae				= &dae;
    problem.events 			= &events;
    problem.linkages		= &linkages;

////////////////////////////////////////////////////////////////////////////
///////////////////  Define & register initial guess ///////////////////////
////////////////////////////////////////////////////////////////////////////

    int nnodes    			= 1000;
    int ncontrols			= problem.phases(1).ncontrols;
    int nstates				= problem.phases(1).nstates;

    MatrixXd u_guess    	=  u0s * ones(ncontrols, nnodes);
    MatrixXd x_guess    	=  zeros(nstates,   nnodes);
    MatrixXd time_guess 	=  linspace(0.0,6e3,nnodes);

    problem.phases(1).guess.controls      = u_guess;
    
    problem.phases(1).guess.states        = x_guess;
    problem.phases(1).guess.states.row(0) = linspace(x0,x_max,nnodes);
    problem.phases(1).guess.states.row(1) = vm_max * ones(1, nnodes);
    
    problem.phases(1).guess.parameters	  << 0;
    
    problem.phases(1).guess.time          = time_guess;
 
////////////////////////////////////////////////////////////////////////////
///////////////////  Enter algorithm options  //////////////////////////////
////////////////////////////////////////////////////////////////////////////
    algorithm.nlp_iter_max              = 1000;
    algorithm.nlp_tolerance             = 1.e-3;
    algorithm.nlp_method                = "IPOPT";
    algorithm.scaling                   = "automatic";
    algorithm.derivatives               = "automatic";
    //algorithm.collocation_method        = "trapezoidal";
    //algorithm.mesh_refinement           = "automatic";


////////////////////////////////////////////////////////////////////////////
///////////////////  Now call PSOPT to solve the problem   /////////////////
////////////////////////////////////////////////////////////////////////////

    psopt(solution, problem, algorithm);

////////////////////////////////////////////////////////////////////////////
///////////  Extract relevant variables from solution structure   //////////
////////////////////////////////////////////////////////////////////////////


    MatrixXd states    = solution.get_states_in_phase(1);
    MatrixXd controls  = solution.get_controls_in_phase(1);
    MatrixXd t         = solution.get_time_in_phase(1);
    MatrixXd gamma     = solution.get_parameters_in_phase(1);

////////////////////////////////////////////////////////////////////////////
///////////  Save solution data to files if desired ////////////////////////
////////////////////////////////////////////////////////////////////////////

    Save(states,   "Acc_x_v-gamma.dat");
    Save(controls, "Acc_u-gamma.dat");
    Save(t,        "Acc_pm-gamma.dat");
    Save(gamma,	   "Acc_gamma.dat");

////////////////////////////////////////////////////////////////////////////
///////////  Plot some results if desired (requires gnuplot) ///////////////
////////////////////////////////////////////////////////////////////////////

    plot(t, states.row(0), problem.name, "pm", "x_ref");

    plot(t, states.row(1), problem.name, "pm", "v");
    
    plot(t, controls/m, problem.name, "pm", "u_ref");


    return 0;
}

////////////////////////////////////////////////////////////////////////////
///////////////////////      END OF FILE     ///////////////////////////////
////////////////////////////////////////////////////////////////////////////
